<footer class="content-footer footer bg-footer-theme bg-primary">
    <div class="container-fluid d-flex flex-wrap justify-content-between py-2 flex-md-row flex-column">
        <div class="mb-2 mb-md-0">
            ©
            <script>
            document.write(new Date().getFullYear());
            </script>
            , made with ❤️ by
            <a href="<?= SITE_URL ?>" target="_blank" class="footer-link fw-bold"><?= APP_NAME ?></a>
        </div>
    </div>
</footer>