<?php
require_once "includes/config/after-login.php";
require_once "includes/functions/functions.php";
require_once "includes/classes/DatabaseMigrator.php";

// Set the migrations directory path
define("MIGRATIONS_DIR", __DIR__ . "/database/migrations");

// Initialize the database migrator
$migrator = new DatabaseMigrator($conn, MIGRATIONS_DIR);

try {
    $filePath = $migrator->createMigrationFile("Test migration");
    echo "Migration created: " . $filePath . PHP_EOL;
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . PHP_EOL;
}

