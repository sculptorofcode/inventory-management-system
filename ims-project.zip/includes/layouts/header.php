<title><?= $title ?> - <?= APP_NAME ?></title>
<link rel="icon" type="image/x-icon" href="assets/images/logo/transparent/favicon.png" />
<!-- FontAwesome Icons for Social Media -->
<link rel="stylesheet" href="assets/libs/fontawesome/css/all.min.css">
<!-- Custom CSS -->
<link rel="stylesheet" href="assets/css/styles.css">
<!-- Toastr CSS -->
<link rel="stylesheet" href="assets/libs/toastr/toastr.min.css">
<!-- jQuery Confirm -->
<link rel="stylesheet" href="assets/libs/jquery-confirm/jquery-confirm.min.css">