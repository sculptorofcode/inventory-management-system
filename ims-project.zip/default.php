<?php include_once 'includes/config/config.php';
$title = "";
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php include_once 'includes/layouts/header.php' ?>
</head>

<body>
</body>

</html>