<?php
// Display all errors for debugging
ini_set("display_errors", 1);
error_reporting(E_ALL);

echo "Starting test script..." . PHP_EOL;

try {
    require_once "includes/config/after-login.php";
    echo "Config loaded" . PHP_EOL;
    
    require_once "includes/functions/functions.php";
    echo "Functions loaded" . PHP_EOL;
    
    require_once "includes/classes/DatabaseMigrator.php";
    echo "DatabaseMigrator class loaded" . PHP_EOL;

    // Set the migrations directory path
    define("MIGRATIONS_DIR", __DIR__ . "/database/migrations");
    echo "MIGRATIONS_DIR defined as: " . MIGRATIONS_DIR . PHP_EOL;

    // Initialize the database migrator
    echo "Creating migrator instance..." . PHP_EOL;
    $migrator = new DatabaseMigrator($conn, MIGRATIONS_DIR);
    echo "Migrator instance created" . PHP_EOL;

    try {
        echo "Attempting to create migration file..." . PHP_EOL;
        $filePath = $migrator->createMigrationFile("Test migration");
        echo "Migration created: " . $filePath . PHP_EOL;
    } catch (Exception $e) {
        echo "Error creating migration: " . $e->getMessage() . PHP_EOL;
    }
} catch (Exception $e) {
    echo "Script error: " . $e->getMessage() . PHP_EOL;
}

