<!-- jQuery -->
<script src="assets/js/jquery-3.7.1.min.js"></script>
<!-- Custom Scripts -->
<script src="assets/js/scripts.js"></script>
<!-- Form Scripts -->
<script src="assets/js/form.js"></script>
<!-- Toastr JS -->
<script src="assets/libs/toastr/toastr.min.js"></script>
<!-- jQuery Confirm -->
<script src="assets/libs/jquery-confirm/jquery-confirm.min.js"></script>